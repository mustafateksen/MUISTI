import Foundation
import CoreGraphics

/// iPhone uygulamasında kullanılacak akış: Ray-Ban'dan gelen kareleri telefonu
/// yormadan işler. DAT SDK'dan gelen HER kareyi `submit` ile buraya ver; gerisini o halleder.
///
/// Telefonu korumak için:
///  1. Saniyede en fazla 1 kare işlenir; diğer kareler HİÇ işlenmeden anında atılır (maliyet ~0).
///  2. Önceki kare hâlâ işleniyorsa yeni kare kuyruğa girmez, atılır → birikme/gecikme olmaz.
///  3. Telefon ısınırsa veya Düşük Güç Modu açıksa işleme aralığı otomatik uzar.
///  4. Önce ucuz kontrol (aynı sahne mi?), sonra pahalı işlem (yüz maskeleme).
///  5. İşlem düşük öncelikli arka plan kuyruğunda; arayüzü ve akışı yavaşlatmaz.
///
/// Gizlilik: ham kare bu sınıftan dışarı çıkmaz; dışarı sadece maskelenmiş JPEG verilir.
/// Maskeleme hata verirse kare atılır (fail-safe).
final class PhoneFramePipeline {

    /// Maskelenmiş, gönderilmeye hazır kare (JPEG) + zaman damgası.
    var onFrameReady: ((Data, Date) -> Void)?
    /// İsteğe bağlı: her işlenen karenin süresi (ms). Test sırasında ölçmek için.
    var onTiming: ((_ gateMs: Double, _ blurMs: Double) -> Void)?

    private let blurrer = FaceBlurrer()
    private let gate = FrameGate()            // aynı sahne filtresi
    private let queue = DispatchQueue(label: "phone-frame-pipeline", qos: .utility)
    private let lock = NSLock()
    private var busy = false
    private var lastAccepted = Date.distantPast

    /// İki işlenen kare arasındaki süre (saniye). Telefonun durumuna göre uyarlanır.
    var interval: TimeInterval {
        let info = ProcessInfo.processInfo
        if info.isLowPowerModeEnabled { return 2 }
        switch info.thermalState {
        case .nominal, .fair: return 1     // normal: saniyede 1 kare
        case .serious:        return 2     // ısınıyor: yavaşla
        case .critical:       return 5     // çok sıcak: neredeyse dur
        @unknown default:     return 1
        }
    }

    /// DAT SDK'dan gelen her kare için çağır (hangi thread olursa olsun).
    func submit(_ frame: CGImage) {
        let now = Date()
        lock.lock()
        let tooSoon = now.timeIntervalSince(lastAccepted) < interval
        if busy || tooSoon {
            lock.unlock()
            return                          // anında at: hiçbir işlem yapılmadı
        }
        busy = true
        lastAccepted = now
        lock.unlock()

        queue.async { [weak self] in
            guard let self else { return }
            defer { self.lock.lock(); self.busy = false; self.lock.unlock() }
            autoreleasepool {
                // 1) Ucuz kontrol: son gönderilenle aynı sahne mi?
                let g0 = Date()
                let decision = self.gate.evaluate(frame)
                let gateMs = Date().timeIntervalSince(g0) * 1000
                guard decision == .send else {
                    self.onTiming?(gateMs, 0)
                    return
                }

                // 2) Pahalı işlem: yüz/kafa maskeleme
                let b0 = Date()
                guard let result = self.blurrer.process(frame),
                      let jpeg = FaceBlurrer.jpegData(result.image, quality: 0.75) else {
                    return                  // fail-safe: maskelenemeyen kare gönderilmez
                }
                self.onTiming?(gateMs, Date().timeIntervalSince(b0) * 1000)
                self.onFrameReady?(jpeg, now)
            }
        }
    }
}

/*
 KULLANIM (iOS uygulamasında):

 let pipeline = PhoneFramePipeline()
 pipeline.onFrameReady = { jpeg, time in
     // jpeg → Nemotron'a gönder / hafızaya kaydet
 }
 pipeline.onTiming = { gateMs, blurMs in
     print("filtre: \(gateMs) ms, maskeleme: \(blurMs) ms")   // test için
 }

 // DAT SDK kare geldiğinde:
 func didReceiveFrame(_ image: CGImage) {
     pipeline.submit(image)
 }

 Projeye eklenecek dosyalar: FaceBlurrer.swift, FrameGate.swift, PhoneFramePipeline.swift
 (HeadTracker.swift sadece video çıktısı için; saniyede 1 karede gerekmez.)
*/
