import CoreGraphics

/// Kafaları kareden kareye takip eder: titreme ve yanıp sönmeyi bitirir.
///
/// - Her kafa bir "iz" olur; yeni algılamayla eşleşince konumu YUMUŞAKÇA güncellenir
///   (ani zıplama yok). Boyut büyürken hemen büyür (gizlilik), küçülürken yavaş küçülür.
/// - Algılama yapılmayan karelerde iz, son hızıyla hareket etmeye devam eder.
///   Böylece algılamayı her karede değil 3 karede bir yapabiliriz → ~3x hız.
/// - Algılayıcı bir kafayı birkaç kez kaçırırsa iz hemen silinmez (yüz açığa çıkmaz).
final class HeadTracker {

    private struct Track {
        var rect: CGRect
        var vx: CGFloat = 0, vy: CGFloat = 0
        var missed = 0
    }

    private var tracks: [Track] = []
    /// Kaç algılama turu boyunca görülmeyen iz korunur.
    let maxMissed: Int
    /// 0–1: yeni algılamaya ne kadar hızlı yaklaşılır (küçük = daha pürüzsüz).
    let smoothing: CGFloat

    init(maxMissed: Int = 3, smoothing: CGFloat = 0.45) {
        self.maxMissed = maxMissed
        self.smoothing = smoothing
    }

    /// Her kare çağrılır. `detections` nil ise bu karede algılama yapılmadı demektir:
    /// izler sadece tahminle ilerler. Dönen kutular o karede maskelenecek kafalardır.
    func update(_ detections: [CGRect]?) -> [CGRect] {
        // 1) Tahmin: her iz son hızıyla ilerler
        for i in tracks.indices {
            tracks[i].rect = tracks[i].rect.offsetBy(dx: tracks[i].vx, dy: tracks[i].vy)
        }
        guard let dets = detections else { return tracks.map(\.rect) }

        // 2) Eşleştirme: merkezler yakın olan iz–algılama çiftleri, en iyi önce
        var pairs: [(t: Int, d: Int, score: CGFloat)] = []
        for (ti, t) in tracks.enumerated() {
            for (di, d) in dets.enumerated() {
                let size = max(t.rect.width, t.rect.height, d.width, d.height)
                let dist = hypot(t.rect.midX - d.midX, t.rect.midY - d.midY)
                if dist < size * 0.8 { pairs.append((ti, di, 1 - dist / (size * 0.8))) }
            }
        }
        pairs.sort { $0.score > $1.score }

        var usedT = Set<Int>(), usedD = Set<Int>()
        let a = smoothing
        for p in pairs where !usedT.contains(p.t) && !usedD.contains(p.d) {
            usedT.insert(p.t); usedD.insert(p.d)
            let old = tracks[p.t].rect, d = dets[p.d]
            let cx = old.midX + a * (d.midX - old.midX)
            let cy = old.midY + a * (d.midY - old.midY)
            // Büyürken hemen, küçülürken yavaş: maske asla yüzden küçük kalmasın
            let w = d.width  > old.width  ? d.width  : old.width  + a * 0.4 * (d.width  - old.width)
            let h = d.height > old.height ? d.height : old.height + a * 0.4 * (d.height - old.height)
            // Hız: bir sonraki karelerde tahmin için (yumuşatılmış)
            tracks[p.t].vx = 0.6 * tracks[p.t].vx + 0.4 * (cx - old.midX)
            tracks[p.t].vy = 0.6 * tracks[p.t].vy + 0.4 * (cy - old.midY)
            tracks[p.t].rect = CGRect(x: cx - w / 2, y: cy - h / 2, width: w, height: h)
            tracks[p.t].missed = 0
        }

        // 3) Eşleşmeyen izler: kaçırıldı say, yavaşla; çok kaçırılırsa sil
        for i in tracks.indices where !usedT.contains(i) {
            tracks[i].missed += 1
            tracks[i].vx *= 0.5
            tracks[i].vy *= 0.5
        }
        tracks.removeAll { $0.missed > maxMissed }

        // 4) Yeni kafalar: hemen maskelenir (gizlilik önce)
        for (di, d) in dets.enumerated() where !usedD.contains(di) {
            tracks.append(Track(rect: d))
        }
        return tracks.map(\.rect)
    }
}
