import Foundation
import Vision
import CoreImage
import CoreImage.CIFilterBuiltins
import CoreVideo
import ImageIO
import UniformTypeIdentifiers

/// Ray-Ban'dan gelen karelerdeki yüzleri, kare telefondan çıkmadan ÖNCE maskeler.
///
/// Gizlilik kuralları:
///  - Algılama hata verirse `nil` döner → o kareyi GÖNDERME, KAYDETME (fail-safe).
///  - Yüz kutusu her yöne `padding` oranında büyütülür (saç/kulak/çene açıkta kalmasın).
///  - Varsayılan güçlü pikselleştirme; istersen `.solid` ile düz siyah kutu.
///
/// Her kare için arka plan kuyruğunda çağır (ana thread'de değil).
final class FaceBlurrer {

    enum Style {
        case smooth      // yumuşak kenarlı elips, pikselleştir + bulanıklaştır (göze en hoş)
        case pixellate   // keskin kare pikselleştirme
        case solid       // düz siyah kutu (en güvenli)
    }

    struct Result {
        let image: CGImage   // yüzleri maskelenmiş kare — sadece bunu kullan
        let faceCount: Int
    }

    private let context = CIContext(options: [.cacheIntermediates: false])
    private let padding: CGFloat
    private let style: Style

    init(padding: CGFloat = 0.3, style: Style = .smooth) {
        self.padding = padding
        self.style = style
    }

    // MARK: - Giriş noktaları

    /// DAT SDK kareyi CVPixelBuffer olarak veriyorsa bunu kullan.
    func process(pixelBuffer: CVPixelBuffer,
                 orientation: CGImagePropertyOrientation = .up) -> Result? {
        let ci = CIImage(cvPixelBuffer: pixelBuffer)
        guard let cg = context.createCGImage(ci, from: ci.extent) else { return nil }
        return process(cg, orientation: orientation)
    }

    /// DAT SDK kareyi UIImage verirse: `process(uiImage.cgImage!)`
    func process(_ cgImage: CGImage,
                 orientation: CGImagePropertyOrientation = .up) -> Result? {
        let input = CIImage(cgImage: cgImage).oriented(orientation)
        guard let rects = findHeads(in: input),
              let masked = apply(rects, to: input),
              let out = context.createCGImage(masked, from: input.extent) else {
            return nil   // fail-safe
        }
        return Result(image: out, faceCount: rects.count)
    }

    /// Maskelenecek baş/yüz kutuları, `input` koordinatlarında. Hata olursa nil (fail-safe).
    /// Algılamayı küçük karede yapıp kutuları büyük kareye ölçekleyerek uygulamak için ayrı.
    func findHeads(in input: CIImage) -> [CGRect]? {
        let extent = input.extent

        // 1) Algılama görüntüsü: küçük karelerde (Ray-Ban 480x640 gibi) 2x büyüt,
        //    uzaktaki küçük yüzleri yakalama oranı artar.
        let scale: CGFloat = min(extent.width, extent.height) < 1000 ? 2 : 1
        let detectImage = input
            .transformed(by: CGAffineTransform(translationX: -extent.origin.x, y: -extent.origin.y))
            .transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        let full = CGRect(x: 0, y: 0, width: extent.width * scale, height: extent.height * scale)

        // 2) Tarama bölgeleri: tüm kare + birbirine binen 2x2 parça.
        //    Parçalarda uzaktaki küçük kafalar algılayıcıya daha büyük görünür.
        var regions = [full]
        let tw = full.width * 0.6, th = full.height * 0.6
        for (fx, fy) in [(0.0, 0.0), (0.4, 0.0), (0.0, 0.4), (0.4, 0.4)] {
            regions.append(CGRect(x: full.width * fx, y: full.height * fy, width: tw, height: th))
        }

        var rects: [CGRect] = []
        for region in regions {
            guard let found = detect(in: detectImage, region: region) else {
                return nil   // fail-safe: algılama hata verdiyse kareyi at
            }
            rects += found
        }

        // Algılama koordinatlarından çıkış karesi koordinatlarına
        rects = rects.map {
            CGRect(x: $0.minX / scale + extent.origin.x, y: $0.minY / scale + extent.origin.y,
                   width: $0.width / scale, height: $0.height / scale)
                .intersection(extent)
        }.filter { !$0.isNull && !$0.isEmpty }

        // Aynı kişinin kopya kutularını (farklı algılayıcı/bölgeden) tek kutuda birleştir
        return Self.mergeDuplicates(rects)
    }

    /// Kutuları görüntüye uygular. Kutular `input` koordinatlarında olmalı.
    func apply(_ rects: [CGRect], to input: CIImage) -> CIImage? {
        let extent = input.extent
        if rects.isEmpty { return input }
        let largest = rects.map { max($0.width, $0.height) }.max() ?? 0

        // Maske + kapatma katmanı
        var mask = CIImage(color: .black).cropped(to: extent)
        let cover: CIImage

        switch style {
        case .smooth:
            // Yumuşak kenarlı elips maske: kutunun içine oturan elips tamamen kapalı,
            // dışına doğru yumuşakça kaybolur → keskin kare bloklar yok.
            for r in rects {
                let g = CIFilter.radialGradient()
                g.center = .zero
                g.radius0 = 0.85          // bu yarıçapa kadar tam kapalı
                g.radius1 = 1.0           // kısa bir geçişle tamamen açık
                g.color0 = .white
                g.color1 = .black
                guard let grad = g.outputImage else { return nil }
                let ellipse = grad
                    // Tam kapalı elips kafa kutusuna oturur; yumuşak kenar sadece
                    // ~%18 dışarı taşar → omuz/gövdeye yayılan hale yok
                    .transformed(by: CGAffineTransform(scaleX: r.width / 2 / 0.85,
                                                       y: r.height / 2 / 0.85))
                    .transformed(by: CGAffineTransform(translationX: r.midX, y: r.midY))
                    .cropped(to: extent)
                mask = ellipse.applyingFilter("CIMaximumCompositing",
                                              parameters: [kCIInputBackgroundImageKey: mask])
            }
            // Önce pikselleştir (geri döndürülemez), sonra yumuşat (göze hoş)
            let pix = CIFilter.pixellate()
            pix.inputImage = input.clampedToExtent()
            pix.center = CGPoint(x: extent.minX, y: extent.minY)
            pix.scale = Float(max(10, largest / 7))
            let blur = CIFilter.gaussianBlur()
            blur.inputImage = pix.outputImage
            blur.radius = Float(max(6, largest / 9))
            guard let b = blur.outputImage else { return nil }
            cover = b.cropped(to: extent)

        case .pixellate, .solid:
            for r in rects {
                mask = CIImage(color: .white).cropped(to: r).composited(over: mask)
            }
            if style == .solid {
                cover = CIImage(color: .black).cropped(to: extent)
            } else {
                let pix = CIFilter.pixellate()
                pix.inputImage = input.clampedToExtent()
                pix.center = CGPoint(x: extent.minX, y: extent.minY)
                pix.scale = Float(max(16, largest / 6))   // ~6x6 blok: kimlik okunamaz
                guard let p = pix.outputImage else { return nil }
                cover = p.cropped(to: extent)
            }
        }

        // Maskenin beyaz yerlerinde kapatma katmanı, diğer yerlerde orijinal
        let blend = CIFilter.blendWithMask()
        blend.inputImage = cover
        blend.backgroundImage = input
        blend.maskImage = mask
        return blend.outputImage?.cropped(to: extent)
    }

    // MARK: - Algılama

    /// `region` içinde yüz + üst gövde + tam vücut algılar; maskelenecek kutuları
    /// `image` piksel koordinatlarında döndürür. Hata olursa nil.
    private func detect(in image: CIImage, region: CGRect) -> [CGRect]? {
        let crop = image.cropped(to: region)
            .transformed(by: CGAffineTransform(translationX: -region.minX, y: -region.minY))

        // Sadece KAFA hedeflenir:
        //  - yüz: önden görünen yüzler (en kesin)
        //  - duruş (pose): burun/göz/kulak/boyun noktaları → yandan, aşağı eğik,
        //    oturan kişilerde bile başın tam yeri
        //  - üst gövde: SADECE yukarıdaki ikisinin bulamadığı kişiler için yedek
        // (Tam vücut algılayıcısı kaldırıldı: gövdeye taşan maskelerin kaynağıydı,
        //  pose oturanları zaten yakalıyor. Hem daha hızlı hem daha isabetli.)
        let faceReq = VNDetectFaceRectanglesRequest()
        let poseReq = VNDetectHumanBodyPoseRequest()
        let upperReq = VNDetectHumanRectanglesRequest()
        upperReq.upperBodyOnly = true

        let handler = VNImageRequestHandler(ciImage: crop, options: [:])
        do {
            try handler.perform([faceReq, poseReq, upperReq])
        } catch {
            return nil
        }

        let w = Int(region.width), h = Int(region.height)
        func toPixels(_ box: CGRect) -> CGRect {
            VNImageRectForNormalizedRect(box, w, h).offsetBy(dx: region.minX, dy: region.minY)
        }
        // Kutunun üst kısmından baş bölgesi (sol-alt orijin → üst = maxY tarafı).
        // Baş kabaca kare olduğu için genişlik yüksekliğe göre sınırlanır.
        func head(_ r: CGRect, heightRatio: CGFloat, widthRatio: CGFloat) -> CGRect {
            let hh = r.height * heightRatio
            let hw = min(r.width * widthRatio, hh * 1.1)
            return CGRect(x: r.midX - hw / 2, y: r.maxY - hh, width: hw, height: hh * 1.05)
        }

        var rects: [CGRect] = (faceReq.results ?? []).map {
            let r = toPixels($0.boundingBox)
            return r.insetBy(dx: -r.width * padding, dy: -r.height * padding)
        }
        for o in poseReq.results ?? [] {
            if let r = headFromPose(o, regionW: w, regionH: h) {
                rects.append(r.offsetBy(dx: region.minX, dy: region.minY))
            }
        }
        // Yedek: üst gövdesi bulunan ama içinde henüz hiç kafa kutusu olmayan kişi
        let precise = rects
        for o in upperReq.results ?? [] where o.confidence > 0.4 {
            let body = toPixels(o.boundingBox)
            let alreadyCovered = precise.contains { body.contains(CGPoint(x: $0.midX, y: $0.midY)) }
            if !alreadyCovered {
                rects.append(head(body, heightRatio: 0.38, widthRatio: 0.55))
            }
        }
        return rects
    }

    /// Duruş noktalarından baş kutusu. Yüz noktaları (burun/göz/kulak) varsa onları,
    /// yoksa boyun + omuzlardan tahmin eder. Koordinatlar bölge içi piksel.
    private func headFromPose(_ o: VNHumanBodyPoseObservation, regionW: Int, regionH: Int) -> CGRect? {
        guard o.confidence > 0.3, let pts = try? o.recognizedPoints(.all) else { return nil }
        func p(_ j: VNHumanBodyPoseObservation.JointName) -> CGPoint? {
            guard let q = pts[j], q.confidence > 0.3 else { return nil }
            return VNImagePointForNormalizedPoint(q.location, regionW, regionH)
        }
        let face = [p(.nose), p(.leftEye), p(.rightEye), p(.leftEar), p(.rightEar)].compactMap { $0 }
        let neck = p(.neck)
        let lS = p(.leftShoulder), rS = p(.rightShoulder)
        let shoulderW: CGFloat? = (lS != nil && rS != nil) ? hypot(lS!.x - rS!.x, lS!.y - rS!.y) : nil

        var center: CGPoint
        var size: CGFloat
        if !face.isEmpty {
            center = CGPoint(x: face.map(\.x).reduce(0, +) / CGFloat(face.count),
                             y: face.map(\.y).reduce(0, +) / CGFloat(face.count))
            let xs = face.map(\.x), ys = face.map(\.y)
            let spread = max(xs.max()! - xs.min()!, ys.max()! - ys.min()!)
            size = max(spread * 2.6, (shoulderW ?? 0) * 0.6)
            if let n = neck { size = max(size, hypot(center.x - n.x, center.y - n.y) * 1.4) }
            if let sw = shoulderW { size = min(size, sw * 0.95) }  // baş omuzdan geniş olamaz
        } else if let n = neck, let sw = shoulderW, sw > 4 {
            // Yüz noktası yok (arkası dönük / tamamen eğik): baş boynun üstünde
            size = sw * 0.65
            center = CGPoint(x: n.x, y: n.y + size * 0.6)
        } else {
            return nil
        }
        // Akıl sağlığı sınırı: tek bir baş karenin %30'undan büyük olamaz
        // (hatalı duruş tahminleri dev kutular üretiyordu)
        size = min(size, CGFloat(min(regionW, regionH)) * 0.3)
        guard size > 4 else { return nil }
        return CGRect(x: center.x - size / 2, y: center.y - size / 2, width: size, height: size)
    }

    // MARK: - Kopya kutuları birleştirme

    /// Büyük ölçüde örtüşen kutuları (IoU > 0.3 ya da biri diğerinin %60'ından
    /// fazlasının içinde) birleşimlerine indirger. Böylece her kişi ~1 kutu olur.
    static func mergeDuplicates(_ input: [CGRect]) -> [CGRect] {
        var boxes = input.sorted { $0.width * $0.height > $1.width * $1.height }
        var changed = true
        while changed {
            changed = false
            var out: [CGRect] = []
            for b in boxes {
                // Sadece birleşim fazla büyümüyorsa birleştir; aksi halde ikisini de
                // ayrı tut. Böylece kutular zincirleme büyüyüp dev bloklara dönüşmez
                // (yazıları kapatıyordu) ama hiçbir bölge açıkta kalmaz.
                if let i = out.firstIndex(where: { a in
                    let u = a.union(b)
                    return overlaps(a, b) &&
                        u.width * u.height <= 1.5 * max(a.width * a.height, b.width * b.height)
                }) {
                    out[i] = out[i].union(b)
                    changed = true
                } else {
                    out.append(b)
                }
            }
            boxes = out
        }
        return boxes
    }

    private static func overlaps(_ a: CGRect, _ b: CGRect) -> Bool {
        let inter = a.intersection(b)
        if inter.isNull || inter.isEmpty { return false }
        let ia = inter.width * inter.height
        let aa = a.width * a.height, ba = b.width * b.height
        let iou = ia / (aa + ba - ia)
        let containment = ia / min(aa, ba)
        return iou > 0.3 || containment > 0.6
    }

    // MARK: - Yardımcı: Nemotron'a göndermek için JPEG

    static func jpegData(_ image: CGImage, quality: CGFloat = 0.8) -> Data? {
        let data = NSMutableData()
        guard let dest = CGImageDestinationCreateWithData(
            data, UTType.jpeg.identifier as CFString, 1, nil) else { return nil }
        CGImageDestinationAddImage(dest, image,
            [kCGImageDestinationLossyCompressionQuality: quality] as CFDictionary)
        guard CGImageDestinationFinalize(dest) else { return nil }
        return data as Data
    }
}

/*
 KULLANIM (DAT SDK'dan gelen her kare için):

 let blurrer = FaceBlurrer()                 // bir kez oluştur
 let queue = DispatchQueue(label: "face-blur", qos: .userInitiated)

 func onFrame(_ frame: CGImage) {
     queue.async {
         guard let safe = blurrer.process(frame) else { return }   // hata → kareyi at
         guard let jpeg = FaceBlurrer.jpegData(safe.image) else { return }
         // jpeg → Nemotron'a gönder / günlüğe kaydet.
         // Ham `frame`i hiçbir yere yazma, loglama, gönderme.
     }
 }
*/
