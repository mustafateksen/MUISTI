import Foundation
import Vision
import CoreImage

/// Ucuz ön filtre: pahalı yüz maskeleme + Nemotron'a gönderme işlemini
/// sadece işe yarayacak karelere uygular. Telefonun yükünü ve API maliyetini düşürür.
///
/// Sıra:  ham kare → FrameGate (ucuz, cihazda) → FaceBlurrer (pahalı) → Nemotron
/// Ham kare hiçbir aşamada telefondan çıkmaz.
final class FrameGate {

    enum Decision {
        case send        // yeni sahne + içinde yazı var → maskele ve gönder
        case duplicate   // son gönderilen kareyle neredeyse aynı → atla
        case noText      // yazı yok → atla (requireText açıksa)
    }

    /// Son gönderilen kareyle ortalama piksel farkı bunun altındaysa "aynı sahne" (0–255).
    let diffThreshold: Double
    /// true: sadece yazı içeren kareler gönderilir (tabela, numara, fiyat...).
    /// false: yazısız sahneler de gönderilir (ör. "anahtarı nereye koydum").
    let requireText: Bool

    private let context = CIContext(options: [.cacheIntermediates: false])
    private var lastSentThumb: [UInt8]?
    private let side = 32

    init(diffThreshold: Double = 12, requireText: Bool = false) {
        self.diffThreshold = diffThreshold
        self.requireText = requireText
    }

    func evaluate(_ image: CGImage) -> Decision {
        // 1) Kopya sahne kontrolü: 32x32 gri küçük resim, ~0.1 ms
        let thumb = thumbnail(image)
        if let last = lastSentThumb, meanAbsDiff(last, thumb) < diffThreshold {
            return .duplicate
        }

        // 2) Yazı var mı? Sadece yazı KUTUSU arar, okumaz → hızlı
        if requireText && !hasText(image) {
            return .noText
        }

        lastSentThumb = thumb
        return .send
    }

    // MARK: - Yardımcılar

    private func thumbnail(_ image: CGImage) -> [UInt8] {
        let ci = CIImage(cgImage: image)
        let sx = CGFloat(side) / ci.extent.width
        let sy = CGFloat(side) / ci.extent.height
        let small = ci.transformed(by: CGAffineTransform(scaleX: sx, y: sy))
            .applyingFilter("CIColorControls", parameters: [kCIInputSaturationKey: 0])
        var buf = [UInt8](repeating: 0, count: side * side * 4)
        context.render(small, toBitmap: &buf, rowBytes: side * 4,
                       bounds: CGRect(x: 0, y: 0, width: side, height: side),
                       format: .RGBA8, colorSpace: CGColorSpaceCreateDeviceRGB())
        return stride(from: 0, to: buf.count, by: 4).map { buf[$0] }   // R kanalı = gri
    }

    private func meanAbsDiff(_ a: [UInt8], _ b: [UInt8]) -> Double {
        var sum = 0
        for i in 0..<min(a.count, b.count) { sum += abs(Int(a[i]) - Int(b[i])) }
        return Double(sum) / Double(a.count)
    }

    private func hasText(_ image: CGImage) -> Bool {
        let req = VNDetectTextRectanglesRequest()
        let handler = VNImageRequestHandler(cgImage: image, options: [:])
        do { try handler.perform([req]) } catch { return true }  // emin değilsek gönder (maskelenecek zaten)
        return !(req.results ?? []).isEmpty
    }
}
