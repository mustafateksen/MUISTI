# Yüz Bulanıklaştırma (Ray-Ban + Nemotron projesi)

Ray-Ban'dan gelen karelerdeki kafaları, kare telefondan çıkmadan ÖNCE bulanıklaştırır.

## iOS uygulamasına eklenecek dosyalar
- `FaceBlurrer.swift`: kafa algılama (yüz + vücut duruşu) ve yumuşak bulanıklaştırma
- `FrameGate.swift`: aynı sahneyi tekrar işlememek için ucuz ön filtre
- `PhoneFramePipeline.swift`: telefonu yormayan akış (saniyede en fazla 1 kare, ısınınca yavaşlar)

Kullanım:
```swift
let pipeline = PhoneFramePipeline()
pipeline.onFrameReady = { jpeg, time in
    // maskelenmiş JPEG → Nemotron'a gönder
}
// DAT SDK'dan gelen her karede:
pipeline.submit(cgImage)
```

Ek kütüphane gerekmez; hepsi iOS'un kendi araçları (Vision, Core Image).

## Mac'te video ile test
- `HeadTracker.swift`: videoda kafaları kareden kareye takip eder (titreme olmaz)
- `main.swift`: test programı
- `hepsini_calistir.sh`: derler ve `test_fotolar/test*.mp4` videolarının hepsini işler

```
bash hepsini_calistir.sh
```
Her video için `sonuc_<ad>/blurred.mp4` (bulanık video) ve `sonuc_<ad>/frames/` (Nemotron'a gidecek kareler) oluşur.

## Gizlilik kuralları
- Ham görüntü telefondan hiçbir yere gitmez; sadece maskelenmiş kare gönderilir.
- Algılama hata verirse kare atılır (videoda siyah kare).
- Bulanıklaştırma önce pikselleştirip sonra yumuşatır: geri çözülemez.
