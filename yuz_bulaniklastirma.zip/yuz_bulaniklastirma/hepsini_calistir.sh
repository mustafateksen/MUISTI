#!/bin/bash
# Kodu derler ve test_fotolar içindeki test*.mp4 videolarının hepsini işler.
cd "$(dirname "$0")" || exit 1

echo "Derleniyor..."
swiftc -O FaceBlurrer.swift HeadTracker.swift FrameGate.swift main.swift -o videoblur || exit 1

for v in test_fotolar/test*.mp4; do
  ad=$(basename "$v" .mp4)
  echo ""
  echo "===== $ad ====="
  ./videoblur "$v" "sonuc_$ad"
done

echo ""
echo "HEPSI BITTI"
