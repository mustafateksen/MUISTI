// Bir videodaki yüzleri FaceBlurrer ile maskeleyip test eder (macOS).
//
// Derle:    swiftc -O FaceBlurrer.swift main.swift -o videoblur
// Çalıştır: ./videoblur video.mov sonuc        (isteğe bağlı 3. argüman: örnekleme fps, varsayılan 1)
//
// Çıktılar (sonuc/ klasörü):
//   blurred.mp4        → tüm kareleri maskelenmiş video (gözle kontrol için)
//   frames/frame_XXXX.jpg → saniyede `fps` kare; gerçek sistemde Nemotron'a gidecek kareler bunlar
// Terminale: kare sayısı, yüz bulunan kare sayısı, kare başına süre, hatalar.

import Foundation
import AVFoundation
import CoreImage
import ImageIO

let args = CommandLine.arguments
guard args.count >= 3 else {
    print("Kullanım: ./videoblur <video> <cikis_klasoru> [fps=1]")
    exit(1)
}
let inURL = URL(fileURLWithPath: (args[1] as NSString).expandingTildeInPath)
let outDir = URL(fileURLWithPath: (args[2] as NSString).expandingTildeInPath)
let sampleFPS = args.count >= 4 ? (Double(args[3]) ?? 1) : 1
let framesDir = outDir.appendingPathComponent("frames")
let fm = FileManager.default
try? fm.removeItem(at: framesDir)   // önceki çalıştırmanın karelerini temizle
try fm.createDirectory(at: framesDir, withIntermediateDirectories: true)
let outVideo = outDir.appendingPathComponent("blurred.mp4")
try? fm.removeItem(at: outVideo)

// MARK: - Videoyu aç

let asset = AVURLAsset(url: inURL)
guard let track = try await asset.loadTracks(withMediaType: .video).first else {
    print("Videoda görüntü izi bulunamadı: \(inURL.path)"); exit(1)
}
let transform = try await track.load(.preferredTransform)
let natural = try await track.load(.naturalSize)
let duration = try await asset.load(.duration).seconds

// Telefon videoları döndürme bilgisi taşır (dikey çekim = 90°). Vision'a doğru yönü ver.
let angle = atan2(transform.b, transform.a) * 180 / .pi
let orientation: CGImagePropertyOrientation
switch Int(angle.rounded()) {
case 90:        orientation = .right
case -90, 270:  orientation = .left
case 180, -180: orientation = .down
default:        orientation = .up
}
let rotated = (orientation == .right || orientation == .left)

// Algılama küçük karede (uzun kenar ≤ 1280): hızlı, bellek dostu.
// Çıkış videosu ise yüksek çözünürlükte (uzun kenar ≤ 1920, yani 1080p): kutular ölçeklenip
// büyük kareye uygulanır → izlenen video net kalır.
let maxSide: CGFloat = 1280
let outMaxSide: CGFloat = 1920
let longSide = max(natural.width, natural.height)
let workScale = min(1, maxSide / longSide)
let outScale = min(1, outMaxSide / longSide)
func even(_ v: CGFloat) -> Int { Int((v / 2).rounded()) * 2 }   // H.264 çift boyut ister
let ow = even(natural.width * outScale), oh = even(natural.height * outScale)
let outW = rotated ? oh : ow
let outH = rotated ? ow : oh
print("Video: \(Int(natural.width))x\(Int(natural.height)), \(String(format: "%.1f", duration)) sn → çıkış \(outW)x\(outH)")

// MARK: - Okuyucu / yazıcı

let reader = try AVAssetReader(asset: asset)
// Kod çözücüden kareleri doğrudan çıkış boyutunda iste (4K'yı kendimiz küçültmeyelim → hız)
let readerOut = AVAssetReaderTrackOutput(track: track, outputSettings: [
    kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
    kCVPixelBufferWidthKey as String: ow,
    kCVPixelBufferHeightKey as String: oh
])
readerOut.alwaysCopiesSampleData = false
reader.add(readerOut)

let writer = try AVAssetWriter(outputURL: outVideo, fileType: .mp4)
let writerIn = AVAssetWriterInput(mediaType: .video, outputSettings: [
    AVVideoCodecKey: AVVideoCodecType.h264,
    AVVideoWidthKey: outW,
    AVVideoHeightKey: outH,
    // Yüksek bit hızı: varsayılan sıkıştırma görüntüyü bozuyordu
    AVVideoCompressionPropertiesKey: [
        AVVideoAverageBitRateKey: Int(Double(outW * outH) * 30 * 0.2),   // 1080p için ~12 Mbps
        AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel
    ]
])
writerIn.expectsMediaDataInRealTime = false
let adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: writerIn, sourcePixelBufferAttributes: [
    kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
    kCVPixelBufferWidthKey as String: outW,
    kCVPixelBufferHeightKey as String: outH
])
writer.add(writerIn)

guard reader.startReading(), writer.startWriting() else {
    print("Başlatılamadı: \(reader.error?.localizedDescription ?? writer.error?.localizedDescription ?? "?")"); exit(1)
}
writer.startSession(atSourceTime: .zero)

// MARK: - Kare kare işle

let blurrer = FaceBlurrer()
let ciContext = CIContext()
let black = CIImage(color: .black).cropped(to: CGRect(x: 0, y: 0, width: outW, height: outH))

var frames = 0, framesWithFaces = 0, totalFaces = 0, failed = 0, saved = 0
let gate = FrameGate()
var sampled = 0, skippedDup = 0, skippedNoText = 0
var gateMs = 0.0
var totalMs = 0.0
var nextSample = 0.0
var lastPrint = Date()
let tracker = HeadTracker()
let detectEvery = 3          // algılama 3 karede bir; aradaki kareleri takipçi doldurur
var detectMs = 0.0, renderMs = 0.0, detections = 0
func atOrigin(_ i: CIImage) -> CIImage {
    i.transformed(by: CGAffineTransform(translationX: -i.extent.minX, y: -i.extent.minY))
}

// Her kare autoreleasepool içinde: yoksa geçici görüntüler birikip belleği doldurur
// (4K videoda "zsh: killed" hatasının sebebi buydu).
var finished = false
while !finished { autoreleasepool {
    guard let sample = readerOut.copyNextSampleBuffer() else { finished = true; return }
    guard let pb = CMSampleBufferGetImageBuffer(sample) else { return }
    let pts = CMSampleBufferGetPresentationTimeStamp(sample)
    frames += 1

    let t0 = Date()

    // Çıkış karesi (kod çözücü boyutu desteklemezse burada ölçeklenir)
    let raw = CIImage(cvPixelBuffer: pb)
    let fix = CGFloat(ow) / raw.extent.width
    let big = atOrigin((fix == 1 ? raw : raw.transformed(by: CGAffineTransform(scaleX: fix, y: fix)))
        .oriented(orientation))
    let k = outScale / workScale          // algılama → çıkış koordinat oranı
    func smallImage() -> CIImage {
        k == 1 ? big : big.transformed(by: CGAffineTransform(scaleX: 1 / k, y: 1 / k))
    }

    // 1) Algılama: sadece her `detectEvery` karede bir, küçük karede
    var heads: [CGRect]? = nil
    var detectFailed = false
    if (frames - 1) % detectEvery == 0 {
        let d0 = Date()
        if let found = blurrer.findHeads(in: smallImage()) {
            heads = found.map { CGRect(x: $0.minX * k, y: $0.minY * k,
                                       width: $0.width * k, height: $0.height * k) }
            detections += 1
            if !found.isEmpty { framesWithFaces += 1; totalFaces += found.count }
        } else {
            detectFailed = true
        }
        detectMs += Date().timeIntervalSince(d0) * 1000
    }

    // 2) Takip: titremesiz, yumuşak hareket eden kafa kutuları
    let tracked = tracker.update(heads)

    // 3) Maskeleme
    let r0 = Date()
    let outImage: CIImage
    if detectFailed {
        outImage = black   // fail-safe
        failed += 1
    } else {
        outImage = blurrer.apply(tracked, to: big) ?? black
    }
    renderMs += Date().timeIntervalSince(r0) * 1000
    totalMs += Date().timeIntervalSince(t0) * 1000

    // Saniyede `sampleFPS` kare örnekle → FrameGate → geçenleri kaydet
    // (gerçek sistemde Nemotron'a gidecek kareler bunlar)
    if !detectFailed, pts.seconds >= nextSample,
       let smallCG = ciContext.createCGImage(smallImage(), from: smallImage().extent) {
        sampled += 1
        do {
            let g0 = Date()
            let decision = gate.evaluate(smallCG)
            gateMs += Date().timeIntervalSince(g0) * 1000
            switch decision {
            case .duplicate: skippedDup += 1
            case .noText:    skippedNoText += 1
            case .send:
                if let cg = ciContext.createCGImage(outImage, from: outImage.extent),
                   let jpeg = FaceBlurrer.jpegData(cg) {
                    let name = String(format: "frame_%04d_%.1fs.jpg", saved, pts.seconds)
                    try? jpeg.write(to: framesDir.appendingPathComponent(name))
                    saved += 1
                }
            }
        }
        nextSample += 1.0 / sampleFPS
    }

    // Videoya yaz
    while !writerIn.isReadyForMoreMediaData { usleep(2000) }
    var outPB: CVPixelBuffer?
    if let pool = adaptor.pixelBufferPool {
        CVPixelBufferPoolCreatePixelBuffer(nil, pool, &outPB)
    }
    if let outPB {
        ciContext.render(outImage, to: outPB)
        adaptor.append(outPB, withPresentationTime: pts)
    }

    if Date().timeIntervalSince(lastPrint) > 2 {
        print(String(format: "  %.0f%% (%d kare)", pts.seconds / max(duration, 0.01) * 100, frames))
        lastPrint = Date()
    }
} }

writerIn.markAsFinished()
await writer.finishWriting()

if reader.status == .failed { print("Okuma hatası: \(reader.error?.localizedDescription ?? "?")") }
if writer.status == .failed { print("Yazma hatası: \(writer.error?.localizedDescription ?? "?")") }

print("""

Bitti.
  Toplam kare:          \(frames)
  Kişi bulunan kare:    \(framesWithFaces)
  Kare başına kişi:     \(String(format: "%.1f", Double(totalFaces) / Double(max(framesWithFaces, 1))))  (kişi olan karelerde ortalama)
  Hatalı kare (siyah):  \(failed)
  Kare başına toplam:   \(String(format: "%.1f", totalMs / Double(max(frames, 1)))) ms
    - algılama:         \(String(format: "%.1f", detectMs / Double(max(detections, 1)))) ms (\(detections) kez, \(detectEvery) karede bir)
    - maskeleme:        \(String(format: "%.1f", renderMs / Double(max(frames, 1)))) ms/kare

  --- Telefondaki gerçek akış simülasyonu (\(sampleFPS) fps) ---
  Örneklenen kare:      \(sampled)
  Atlandı (aynı sahne): \(skippedDup)
  Atlandı (yazı yok):   \(skippedNoText)
  Gönderilecek kare:    \(saved)  (%\(sampled > 0 ? saved * 100 / sampled : 0))
  Ön filtre süresi:     \(String(format: "%.1f", gateMs / Double(max(sampled, 1)))) ms/kare
  Tahmini yük:          saniyede ~\(String(format: "%.0f", gateMs / Double(max(sampled, 1)) + Double(saved) / Double(max(sampled, 1)) * totalMs / Double(max(frames, 1)))) ms işlem (Mac'te)
  Video:   \(outVideo.path)
  Kareler: \(framesDir.path)
""")
